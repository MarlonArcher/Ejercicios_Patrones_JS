package ec.edu.archer.singleton;

public class Printer {
    private static Printer instance;
    private int counter = 0;
    private Printer() {
    }
    public static Printer getInstance() {
        return instance == null ? instance = new Printer() : instance;
    }
    public void print(String message) {
        System.out.println(message+"\nPaginas impresas hoy: "+(++counter)+"\n--------------------------");
    }
}
