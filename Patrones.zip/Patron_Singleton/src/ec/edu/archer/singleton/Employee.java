package ec.edu.archer.singleton;

public class Employee {
    private String name;
    private String role;
    private String assignment;

    public Employee(String name, String role, String assignment) {
        this.name = name;
        this.role = role;
        this.assignment = assignment;
    }

    public void printCurrentAssignment() {
        Printer impresora =  Printer.getInstance();
        impresora.print("Employee:\nNombre: "+name+"\nRol: "+role+"\nAsignacion: "+assignment);
    }
}
