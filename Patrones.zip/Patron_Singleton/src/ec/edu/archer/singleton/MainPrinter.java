package ec.edu.archer.singleton;

public class MainPrinter {
    public static void main(String[] args) {
        Employee e1 = new Employee("Juan", "CEO", "Ejecutivo de Marketing");
        Employee e2 = new Employee("Pedro", "Consultor", "Consultoria de negocios");
        Employee e3 = new Employee("Maria", "Programador", "Desarrollo de software");
        Employee e4 = new Employee("Jose", "Vendedor", "Ventas de software");
        e1.printCurrentAssignment();
        e2.printCurrentAssignment();
        e3.printCurrentAssignment();
        e4.printCurrentAssignment();
    }
}
