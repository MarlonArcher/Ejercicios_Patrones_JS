package ac.edu.archer.builderPizza;

public class MainPizza {
    public static void main(String[] args) {
        CocinaDirector director = new CocinaDirector(new HawaiPizzaBuilder());
        director.construirPizza();
        Pizza pizza = director.getPizza();
        System.out.println("Pizza Hawaiana");
        System.out.println(pizza.MostrarPizza());

        director = new CocinaDirector(new PicantePizzaBuilder());
        director.construirPizza();
        pizza = director.getPizza();
        System.out.println("Pizza Picante");
        System.out.println(pizza.MostrarPizza());
    }
}
