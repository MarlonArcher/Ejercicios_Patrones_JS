package ac.edu.archer.builderVehiculo;

public class AppVehiculo {
    public static void main(String[] args) {
        VehiculoDirector directorAudi = new VehiculoDirector(new VehiculoAudiBuilder());
        directorAudi.construirVehiculo();
        Vehiculo AudiA3 = directorAudi.getVehiculo();
        System.out.println("Audi A3");
        System.out.println(AudiA3.mostrarVehiculo());
        System.out.println("--------------------------------------------------");
        VehiculoDirector directorBMW = new VehiculoDirector(new VehiculoBMWBuilder());
        directorBMW.construirVehiculo();
        Vehiculo BMWSerie5 = directorBMW.getVehiculo();
        System.out.println("BMW Serie 5");
        System.out.println(BMWSerie5.mostrarVehiculo());
        System.out.println("--------------------------------------------------");
    }
}
