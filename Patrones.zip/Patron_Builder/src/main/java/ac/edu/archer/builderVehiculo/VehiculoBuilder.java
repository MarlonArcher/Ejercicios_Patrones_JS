package ac.edu.archer.builderVehiculo;

public abstract class VehiculoBuilder {
    protected Vehiculo vehiculo;

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void nuevoVehiculo() {
        vehiculo = new Vehiculo();
    }
    //Region de los metodos abstractos (pasos)
    public abstract void definirVehiculo();
    public abstract void construirMotor();
    public abstract void construirCarroceria();
    public abstract void construirRuedas();
    public abstract void definirExtras();
}
