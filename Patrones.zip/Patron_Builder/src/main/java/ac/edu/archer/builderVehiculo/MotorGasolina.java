package ac.edu.archer.builderVehiculo;

public class MotorGasolina implements IMotor{
    int cilindraje = 0;
    int potencia = 0;

    @Override
    public void SetPotenncia(int potencia) {
        this.potencia = potencia;
    }

    @Override
    public void SetCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }

    @Override
    public String getDefinicionMotor() {
        return "Cilindraje: "+this.cilindraje+"----- Potencia: "+this.potencia;
    }

    @Override
    public String inyectarCombustible(int cantidad) {
        return String.format("Motor Gasolina: Inyectando %d ml de combustible", cantidad);
    }

    @Override
    public String consumirCombustible() {
        return "Motor Gasolina realiza combustion de gasolina";
    }
}
