package ac.edu.archer.builderVehiculo;

public interface IMotor {
    void SetPotenncia(int potencia);
    void SetCilindraje(int cilindraje);
    String getDefinicionMotor();
    String inyectarCombustible(int cantidad);
    String consumirCombustible();
}
