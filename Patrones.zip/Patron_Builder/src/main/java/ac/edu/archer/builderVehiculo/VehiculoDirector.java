package ac.edu.archer.builderVehiculo;

public class VehiculoDirector {
    private VehiculoBuilder vehiculoBuilder;

    public VehiculoDirector(VehiculoBuilder vehiculoBuilder) {
        this.vehiculoBuilder = vehiculoBuilder;
    }

    public void construirVehiculo() {
        vehiculoBuilder.nuevoVehiculo();
        vehiculoBuilder.definirVehiculo();
        vehiculoBuilder.construirMotor();
        vehiculoBuilder.construirCarroceria();
        vehiculoBuilder.construirRuedas();
        vehiculoBuilder.definirExtras();
    }

    public Vehiculo getVehiculo() {
        return vehiculoBuilder.getVehiculo();
    }
}
