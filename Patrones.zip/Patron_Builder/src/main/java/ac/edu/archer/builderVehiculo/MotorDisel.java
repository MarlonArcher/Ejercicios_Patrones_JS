package ac.edu.archer.builderVehiculo;

public class MotorDisel implements IMotor{
    int cilindraje = 0;
    int potencia = 0;

    @Override
    public void SetPotenncia(int potencia) {
        this.potencia = potencia;
    }

    @Override
    public void SetCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }

    @Override
    public String getDefinicionMotor() {
        return "Cilindraje: "+this.cilindraje+"----- Potencia: "+this.potencia;
    }

    @Override
    public String inyectarCombustible(int cantidad) {
        return String.format("Motor Disel: Inyectando %d ml de combustible", cantidad);
    }

    @Override
    public String consumirCombustible() {
        return "Motor Disel realiza combustion de Gasolina";
    }
}
