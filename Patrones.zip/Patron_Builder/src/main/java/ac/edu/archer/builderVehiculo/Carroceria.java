package ac.edu.archer.builderVehiculo;

public class Carroceria {
    private String material;
    private String tipoCarroceria;
    private boolean habitaculoReforzado;
    //métodos

    public String getMaterial() {
        return this.material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getTipoCarroceria() {
        return this.tipoCarroceria;
    }

    public void setTipoCarroceria(String tipoCarroceria) {
        this.tipoCarroceria = tipoCarroceria;
    }

    public boolean isHabitaculoReforzado() {
        return this.habitaculoReforzado;
    }

    public void setHabitaculoReforzado(boolean habitaculoReforzado) {
        this.habitaculoReforzado = habitaculoReforzado;
    }
}
