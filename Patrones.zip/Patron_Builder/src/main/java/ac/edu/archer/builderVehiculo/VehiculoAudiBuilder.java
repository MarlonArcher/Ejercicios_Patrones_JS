package ac.edu.archer.builderVehiculo;

public class VehiculoAudiBuilder extends VehiculoBuilder{
    @Override
    public void definirVehiculo() {
        this.vehiculo.marca = "Audi";
        this.vehiculo.modelo = "A3 sportback";
    }

    @Override
    public void construirMotor() {
        this.vehiculo.tipoMotor = new MotorDisel();
        this.vehiculo.tipoMotor.SetCilindraje(2600);
        this.vehiculo.tipoMotor.SetPotenncia(300);
    }

    @Override
    public void construirCarroceria() {
        this.vehiculo.carroceria = new Carroceria();
        this.vehiculo.carroceria.setTipoCarroceria("Deportivo");
        this.vehiculo.carroceria.setMaterial("Fibra de Carbono");
        this.vehiculo.carroceria.setHabitaculoReforzado(true);
        this.vehiculo.color = "Rojo";
    }

    @Override
    public void construirRuedas() {
        this.vehiculo.tipoRueda = new Ruedas();
        this.vehiculo.tipoRueda.setDiametro(17);
        this.vehiculo.tipoRueda.setLlantas("Aluminio");
        this.vehiculo.tipoRueda.setNeumaticos("Michelin");
    }

    @Override
    public void definirExtras() {
        this.vehiculo.bloqueoCentralizao = true;
        this.vehiculo.direccionAsistida = true;
    }
}
