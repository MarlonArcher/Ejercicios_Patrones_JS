package ac.edu.archer.builderVehiculo;

public class Vehiculo {
    public String color;
    public String marca;
    public String modelo;
    public Carroceria carroceria;
    public IMotor tipoMotor;
    public Ruedas tipoRueda;
    public boolean bloqueoCentralizao;
    public boolean direccionAsistida;
    public String mostrarVehiculo(){
        StringBuilder sb = new StringBuilder();
        String nl = System.getProperty("line.separator");
        sb.append("Soy un vehiculo de color: ").append(color).append(", de marca: ").append(marca).append(nl);
        sb.append("y de modelo: ").append(modelo).append(nl);
        sb.append("con estilo: ").append(carroceria.getTipoCarroceria()).append(nl);
        sb.append(bloqueoCentralizao ? "con ":"sin ").append("bloqueo centralizado: ").append(nl);
        sb.append(direccionAsistida ? "con ":"sin ").append("direccion asistida ").append(nl);
        sb.append("Carroceria de: ").append(carroceria.getMaterial()).append(nl);
        sb.append(carroceria.isHabitaculoReforzado() ? "con ":"sin ").append("habitaculo reforzado ").append(nl);
        sb.append("Ruedas con llantas ").append(tipoRueda.getLlantas()).append(" de ").append(tipoRueda.getDiametro()).append(" cm").append(nl);
        sb.append("Neumaticos ").append(tipoRueda.getNeumaticos()).append(nl);
        sb.append("Motor: ").append(tipoMotor.getDefinicionMotor()).append(nl);
        sb.append("Respuesta del moor").append(tipoMotor.inyectarCombustible(100)).append(nl);
        return sb.toString();
    }
}
