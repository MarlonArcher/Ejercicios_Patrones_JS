package ac.edu.archer.builderPizza;

public class Pizza {
    private String masa;
    private String salsa;
    private String relleno;

    public Pizza() {
    }

    public Pizza(String masa, String salsa, String relleno) {
        this.masa = masa;
        this.salsa = salsa;
        this.relleno = relleno;
    }

    public String getMasa() {
        return masa;
    }

    public String getSalsa() {
        return salsa;
    }

    public String getRelleno() {
        return relleno;
    }

    public void setMasa(String masa) {
        this.masa = masa;
    }

    public void setSalsa(String salsa) {
        this.salsa = salsa;
    }

    public void setRelleno(String relleno) {
        this.relleno = relleno;
    }

    public String MostrarPizza(){
        StringBuilder sb = new StringBuilder();
        String nl = System.getProperty("line.separator");
        sb.append("Soy una Pizza con masa: ").append(masa).append(", con salsa: ").append(salsa).append(nl);
        sb.append("y con relleno de: ").append(relleno).append(nl);
        return sb.toString();
    }
}
