package ac.edu.archer.builderPizza;

public class CocinaDirector {
    private IPizzaBuilder Builder;

    public CocinaDirector(IPizzaBuilder builder) {
        this.Builder = builder;
    }
    public void construirPizza(){
        this.Builder.buildMasa();
        this.Builder.buildSalsa();
        this.Builder.buildRelleno();
    }
    public Pizza getPizza(){
        return this.Builder.getPizza();
    }
}
