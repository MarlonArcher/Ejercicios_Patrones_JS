package ac.edu.archer.builderVehiculo;

public class VehiculoBMWBuilder extends VehiculoBuilder{
    @Override
    public void definirVehiculo() {
        this.vehiculo.marca = "BMW";
        this.vehiculo.modelo = "BMW Serie 5";
    }

    @Override
    public void construirMotor() {
        this.vehiculo.tipoMotor = new MotorGasolina();
        this.vehiculo.tipoMotor.SetCilindraje(4300);
        this.vehiculo.tipoMotor.SetPotenncia(560);
    }

    @Override
    public void construirCarroceria() {
        this.vehiculo.carroceria = new Carroceria();
        this.vehiculo.carroceria.setTipoCarroceria("Monovalente");
        this.vehiculo.carroceria.setMaterial("Acero");
        this.vehiculo.carroceria.setHabitaculoReforzado(false);
        this.vehiculo.color = "Negro";
    }

    @Override
    public void construirRuedas() {
        this.vehiculo.tipoRueda = new Ruedas();
        this.vehiculo.tipoRueda.setDiametro(17);
        this.vehiculo.tipoRueda.setLlantas("Hierro");
        this.vehiculo.tipoRueda.setNeumaticos("Firestone");
    }

    @Override
    public void definirExtras() {
        this.vehiculo.bloqueoCentralizao = true;
        this.vehiculo.direccionAsistida = false;
    }
}
