package ec.edu.archer.factory;

public class MainFigure {
    public static void main(String[] args) {
        FigureManager figureManager = new FigureManager(FigureType.DIAMOND);
        figureManager.createFigure();
        //System.out.println(figureManager.getFigure().getName());
        //System.out.println(figureManager.getFigure().getArea());
        //System.out.println(figureManager.getFigure().numberOfSlides());
    }
}
