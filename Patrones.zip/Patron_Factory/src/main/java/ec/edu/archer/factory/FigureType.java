package ec.edu.archer.factory;

public enum FigureType {
    CIRCLE, TRIANGLE, SQUARE, DIAMOND
}
