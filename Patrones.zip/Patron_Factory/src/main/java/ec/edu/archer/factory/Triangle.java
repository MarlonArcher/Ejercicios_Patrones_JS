package ec.edu.archer.factory;

public class Triangle extends Figure{
    private double base;
    private double height;
    public Triangle(String name, double base, double height){
        super(name);
        this.base = base;
        this.height = height;
    }
    @Override
    public double getArea() {
        return (base * height)/2;
    }

    @Override
    public double numberOfSlides() {
        return 3;
    }

    @Override
    public String toString() {
        return "Triangle{" +
                "base=" + base +
                ", height=" + height +
                '}';
    }
}
