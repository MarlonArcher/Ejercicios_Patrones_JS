package ec.edu.archer.factory.creator;

import ec.edu.archer.factory.Figure;

public class FigureManagerFactory {
    public Figure figure;
    private FigureCreator creador;

    public FigureManagerFactory() {
    }
    public void setFigure(FigureCreator creador){
        this.creador = creador;
    }
    public void createFigure(){
        this.figure = this.creador.createFigur();
    }
    public Figure getFigure(){
        return this.figure;
    }
}
