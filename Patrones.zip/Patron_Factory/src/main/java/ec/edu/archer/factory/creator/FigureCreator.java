package ec.edu.archer.factory.creator;

import ec.edu.archer.factory.Figure;
public abstract class FigureCreator {
    public abstract Figure createFigur();

}
