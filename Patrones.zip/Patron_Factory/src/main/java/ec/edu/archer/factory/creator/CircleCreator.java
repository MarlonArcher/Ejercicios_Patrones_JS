package ec.edu.archer.factory.creator;

import ec.edu.archer.factory.Circle;
import ec.edu.archer.factory.Figure;

public class CircleCreator extends FigureCreator{

    @Override
    public Figure createFigur() {
        return new Circle("Circulo",2);
    }
}
