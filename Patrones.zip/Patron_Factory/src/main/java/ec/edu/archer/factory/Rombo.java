package ec.edu.archer.factory;

public class Rombo extends Figure{
    private double DiagonalMayor;
    private double DiagonalMenor;

    public Rombo(String name, double diagonalMayor, double diagonalMenor) {
        super(name);
        DiagonalMayor = diagonalMayor;
        DiagonalMenor = diagonalMenor;
    }

    @Override
    public double getArea() {
        return (DiagonalMayor*DiagonalMenor)/2;
    }

    @Override
    public double numberOfSlides() {
        return 4;
    }

    @Override
    public String toString() {
        return "Rombo{" +
                "DiagonalMayor=" + DiagonalMayor +
                ", DiagonalMenor=" + DiagonalMenor +
                '}';
    }
}
