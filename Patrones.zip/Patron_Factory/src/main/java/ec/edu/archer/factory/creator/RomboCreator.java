package ec.edu.archer.factory.creator;

import ec.edu.archer.factory.Figure;
import ec.edu.archer.factory.Rombo;

public class RomboCreator extends FigureCreator{

    @Override
    public Figure createFigur() {
        return new Rombo("Rombo",15,10);
    }
}
