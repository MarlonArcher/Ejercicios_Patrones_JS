package ec.edu.archer.factory.creator;

import ec.edu.archer.factory.Figure;
import ec.edu.archer.factory.Square;

public class SquareCreator extends FigureCreator{
    @Override
    public Figure createFigur() {
        return new Square("Cuadrado",3);
    }
}
