package ec.edu.archer.factory.creator;

import ec.edu.archer.factory.Figure;
import ec.edu.archer.factory.Triangle;

public class TriangleCreator extends FigureCreator{
    @Override
    public Figure createFigur() {
        return new Triangle("Triangulo",4,5);
    }
}
