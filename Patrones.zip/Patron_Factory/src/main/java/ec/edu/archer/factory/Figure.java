package ec.edu.archer.factory;

public abstract class Figure {
    private String name;
    public  Figure(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String setName(String name) {
        return this.name = name;
    }

    public abstract double getArea();
    public abstract double numberOfSlides();
}
