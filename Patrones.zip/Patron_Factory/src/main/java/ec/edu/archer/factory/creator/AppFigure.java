package ec.edu.archer.factory.creator;

public class AppFigure {
    public static void main(String[] args) {
        //Utilizando un Factory con creadores concretos
        FigureManagerFactory figureManager = new FigureManagerFactory();
        figureManager.setFigure(new CircleCreator());
        figureManager.createFigure();
        System.out.println(figureManager.getFigure().getName());
        System.out.println(figureManager.getFigure().getArea());
        System.out.println(figureManager.getFigure().numberOfSlides());
        System.out.println("*********************************************");
        figureManager.setFigure(new SquareCreator());
        figureManager.createFigure();
        System.out.println(figureManager.getFigure().getName());
        System.out.println(figureManager.getFigure().getArea());
        System.out.println(figureManager.getFigure().numberOfSlides());
        System.out.println("*********************************************");
        figureManager.setFigure(new TriangleCreator());
        figureManager.createFigure();
        System.out.println(figureManager.getFigure().getName());
        System.out.println(figureManager.getFigure().getArea());
        System.out.println(figureManager.getFigure().numberOfSlides());
        System.out.println("*********************************************");
        figureManager.setFigure(new RomboCreator());
        figureManager.createFigure();
        System.out.println(figureManager.getFigure().getName());
        System.out.println(figureManager.getFigure().getArea());
        System.out.println(figureManager.getFigure().numberOfSlides());
        System.out.println("*********************************************");
    }
}
