package ec.edu.archer.factory;

public class FigureManager {
    private Figure figure;
    private FigureType figureType;
    public FigureManager(FigureType figureType){
        this.figureType = figureType;
    }
    public Figure getFigure(){
        return figure;
    }
    public void setFigure(Figure figure){
        this.figure = figure;
    }
    public void createFigure(){
        //Method Factory
        switch (this.figureType){
            case CIRCLE:
                figure = new Circle("Circulo", 5);
                break;
            case TRIANGLE:
                figure = new Triangle("Triangulo", 5, 10);
                break;
            case SQUARE:
                figure = new Square("Cuadrado", 5);
                break;
            default:
                System.out.println("Figure type not supported");
                assert false: "Figure type not supported";
        }
    }

    @Override
    public String toString() {
        return "FigureManager{" +
                "figure=" + figure +
                ", figureType=" + figureType +
                '}';
    }
}
