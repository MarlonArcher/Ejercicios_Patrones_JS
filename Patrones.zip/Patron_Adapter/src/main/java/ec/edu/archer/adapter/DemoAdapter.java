package ec.edu.archer.adapter;

public class DemoAdapter {
    public static void main(String[] args) {
        AudioPlayer audioplayer = new AudioPlayer();
        audioplayer.play("mp3", "Boiler.mp3");
        audioplayer.play("vlc", "Boiler.vlc");
        audioplayer.play("mp4", "Boiler.mp4");
        audioplayer.play("avi", "Boiler.avi");
    }
}
