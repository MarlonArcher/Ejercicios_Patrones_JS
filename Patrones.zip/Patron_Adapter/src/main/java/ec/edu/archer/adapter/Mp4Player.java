package ec.edu.archer.adapter;

public class Mp4Player implements IAdvancedMedialayer{
    @Override
    public void playVLC(String fileName) {
    }

    @Override
    public void playMP4(String fileName) {
        System.out.println("Reproduccion de Archivos MP4. Nombre= "+fileName);
    }
}
