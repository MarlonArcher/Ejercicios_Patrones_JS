package ec.edu.archer.adapter;

public class MediaAdapter implements IMediaPlayer{
    //Clase adaptadora
    IAdvancedMedialayer advancedMedialayer;
    public MediaAdapter(String typeAudio) {
        if (typeAudio.equalsIgnoreCase("vlc")){
            advancedMedialayer = new VlCPlayer();
        } else if (typeAudio.equalsIgnoreCase("MP4")) {
            advancedMedialayer = new Mp4Player();
        }
    }

    @Override
    public void play(String typeAudio, String fileName) {

        if (typeAudio.equalsIgnoreCase("vlc")){
            advancedMedialayer.playVLC(fileName);
        } else if (typeAudio.equalsIgnoreCase("MP4")) {
            advancedMedialayer.playMP4(fileName);
        }
    }
}
