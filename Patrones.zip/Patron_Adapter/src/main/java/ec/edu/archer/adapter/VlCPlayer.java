package ec.edu.archer.adapter;

public class VlCPlayer implements IAdvancedMedialayer{
    @Override
    public void playVLC(String fileName) {
        System.out.println("Reproduccion de Archivos VLC. Nombre= "+fileName);
    }

    @Override
    public void playMP4(String fileName) {

    }
}
