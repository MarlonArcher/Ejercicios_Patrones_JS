package ec.edu.archer.adapterFormas;

import java.util.List;

public class AppFormas {
    public static void main(String[] args) {
        IForma linea = new Linea();
        IForma rombo = new Rombo();
        IForma cuadroTexto = new CuadroTextoAdaptador();
        List<IForma> formas = List.of(linea, rombo, cuadroTexto);
        for(IForma forma: formas){
            forma.dibujar();
        }
    }
}
