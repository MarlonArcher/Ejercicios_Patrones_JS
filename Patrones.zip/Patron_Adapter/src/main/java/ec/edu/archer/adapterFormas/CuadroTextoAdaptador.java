package ec.edu.archer.adapterFormas;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

public class CuadroTextoAdaptador implements IForma{
    JTextPane text;
    JFrame ventana;
    public CuadroTextoAdaptador(){
        ventana = new JFrame("Cuadro de Texto");
        text = new JTextPane();
    }
    @Override
    public void dibujar() {
        SimpleAttributeSet atributos = new SimpleAttributeSet();
        //Negrita
        StyleConstants.setBold(atributos, true);
        //Cursiba
        StyleConstants.setItalic(atributos, true);
        //Subrayado
        StyleConstants.setUnderline(atributos, true);
        //Fuente tamaño
        StyleConstants.setFontSize(atributos, 20);
        try {
            text.getStyledDocument().insertString(text.getStyledDocument().getLength(), "Hola mundo", atributos);
        } catch (BadLocationException e) {
            throw new RuntimeException(e);
        }
        ventana.add(text);
        ventana.pack();
        ventana.setVisible(true);
    }
}
