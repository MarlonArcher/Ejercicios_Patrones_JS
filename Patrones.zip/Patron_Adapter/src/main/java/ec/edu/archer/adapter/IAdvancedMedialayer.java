package ec.edu.archer.adapter;

public interface IAdvancedMedialayer {
    public void playVLC(String fileName);
    public void playMP4(String fileName);
}
