package ec.edu.archer.adapterFormas;

public interface IForma {
    public void dibujar();
}
