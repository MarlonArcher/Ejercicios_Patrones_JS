package ec.edu.archer.adapter;

public interface IMediaPlayer {
    //Interfaz Tarjet
    public void play(String typeAudio,String fileName);

}
