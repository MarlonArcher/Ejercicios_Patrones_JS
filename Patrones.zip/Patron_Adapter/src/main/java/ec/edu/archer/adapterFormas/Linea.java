package ec.edu.archer.adapterFormas;

public class Linea implements IForma{
    @Override
    public void dibujar() {
        System.out.println("-----------------------------------------");
    }
}
