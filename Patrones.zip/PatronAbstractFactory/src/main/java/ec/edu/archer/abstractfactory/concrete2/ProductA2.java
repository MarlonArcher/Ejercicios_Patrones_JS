package ec.edu.archer.abstractfactory.concrete2;

import ec.edu.archer.abstractfactory.IProductA;

public class ProductA2 implements IProductA {

    @Override
    public String view() {
        return "Se a creado un producto A2";
    }
}
