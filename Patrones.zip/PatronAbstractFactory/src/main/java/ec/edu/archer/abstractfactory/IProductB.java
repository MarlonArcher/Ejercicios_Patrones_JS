package ec.edu.archer.abstractfactory;

public interface IProductB {
    public String view();
}
