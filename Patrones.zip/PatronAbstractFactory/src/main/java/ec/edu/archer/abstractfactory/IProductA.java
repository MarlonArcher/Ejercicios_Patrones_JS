package ec.edu.archer.abstractfactory;

public interface IProductA {
    public String view();
}
