package ec.edu.archer.abstractfactory.concrete1;

import ec.edu.archer.abstractfactory.IProductB;

public class ProductB1 implements IProductB {
    @Override
    public String view() {
        return "Se a creado un producto B1";
    }
}
