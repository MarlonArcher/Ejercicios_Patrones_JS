package ec.edu.archer.abstractfactory.concrete2;

import ec.edu.archer.abstractfactory.IProductB;

public class ProductB2 implements IProductB {
    @Override
    public String view() {
        return "Se a creado un producto B2";
    }
}
