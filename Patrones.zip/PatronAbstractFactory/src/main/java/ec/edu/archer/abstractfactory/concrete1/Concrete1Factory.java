package ec.edu.archer.abstractfactory.concrete1;

import ec.edu.archer.abstractfactory.AbstractFactory;
import ec.edu.archer.abstractfactory.IProductA;
import ec.edu.archer.abstractfactory.IProductB;

public class Concrete1Factory extends AbstractFactory {
    private IProductA productA;
    private IProductB productB;
    @Override
    public IProductA getProductA() {
        if(productA== null) {
            productA = new ProductA1();
        }
        return productA;
    }
    @Override
    public IProductB getProductB() {
        if(productB== null) {
            productB = new ProductB1();
        }
        return productB;
    }
}
