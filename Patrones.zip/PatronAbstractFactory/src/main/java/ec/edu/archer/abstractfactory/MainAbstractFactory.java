package ec.edu.archer.abstractfactory;

import ec.edu.archer.abstractfactory.concrete1.Concrete1Factory;
import ec.edu.archer.abstractfactory.concrete2.Concrete2Factory;

public class MainAbstractFactory {
    public static void main(String[] args) {
        System.out.println("-----------Fabrica Familia 1-----------");
        AbstractFactory.setAbstractFactory(new Concrete1Factory());
        AbstractFactory miFabrica1 = AbstractFactory.getAbstractFactory();
        System.out.println(miFabrica1.getProductA().view());
        System.out.println(miFabrica1.getProductB().view());
        System.out.println("-----------Fabrica Familia 2-----------");
        AbstractFactory.setAbstractFactory(new Concrete2Factory());
        AbstractFactory miFabrica2 = AbstractFactory.getAbstractFactory();
        System.out.println(miFabrica2.getProductA().view());
        System.out.println(miFabrica2.getProductB().view());
    }
}
