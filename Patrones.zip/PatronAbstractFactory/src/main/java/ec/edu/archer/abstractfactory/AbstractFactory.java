package ec.edu.archer.abstractfactory;

public abstract class AbstractFactory {
    private static AbstractFactory abstractfactory;

    public static void setAbstractFactory(AbstractFactory abstractfactory) {
        AbstractFactory.abstractfactory = abstractfactory;
    }
    public static AbstractFactory getAbstractFactory() {
        return AbstractFactory.abstractfactory;
    }
    public abstract IProductA getProductA();
    public abstract IProductB getProductB();
}
