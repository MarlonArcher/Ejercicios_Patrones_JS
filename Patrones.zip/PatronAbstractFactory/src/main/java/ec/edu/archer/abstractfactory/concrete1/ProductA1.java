package ec.edu.archer.abstractfactory.concrete1;

import ec.edu.archer.abstractfactory.IProductA;

public class ProductA1 implements IProductA {

    @Override
    public String view() {
        return "Se a creado un producto A1";
    }
}
