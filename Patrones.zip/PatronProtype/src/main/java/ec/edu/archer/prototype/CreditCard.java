package ec.edu.archer.prototype;
public class CreditCard implements Cloneable{
    private String name;
    private String cardID;
    private String expirationDate;
    private String cvv;

    public CreditCard(String name, String cardID,String expirationDate, String cvv) {
        this.name = name;
        this.cardID = cardID;
        this.expirationDate = expirationDate;
        this.cvv = cvv;
    }
    public CreditCard clone() throws CloneNotSupportedException{
        return (CreditCard) super.clone();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCardID() {
        return cardID;
    }
    public void setCardID(String cardID) {
        this.cardID = cardID;
    }
    public String getExpirationDate() {
        return expirationDate;
    }
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }
    public String getCvv() {
        return cvv;
    }
    public void setCvv(String cvv) {
        this.cvv = cvv;
    }
    @Override
    public String toString() {
        return "CreditCard{" +
                "name='" + name + '\'' +
                ", cardID='" + cardID + '\'' +
                ", expirationDate='" + expirationDate + '\'' +
                ", cvv='" + cvv + '\'' +
                '}';
    }
}
