package ec.edu.archer.prototype;

public class MainPrototype {
    public static void main(String[] args) {
        CreditCard creditCard = new CreditCard("Juan Perez",
                "123456789",
                "12/12/2020",
                "123");
        System.out.println(creditCard);
        try {
            CreditCard creditCard1 = creditCard.clone();
            creditCard1.setName("Maria Perez");
            creditCard1.setCardID("987654321");
            creditCard1.setExpirationDate("12/12/2021");
            System.out.println(creditCard1);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}
